const express = require('express');
const router = express.Router();

// Middleware to protect profile routes
router.use((req, res, next) => {
    if (!req.session.user) {
        return res.redirect('/login');
    }
    next();
});

// Route to render profile page
router.get('/', (req, res) => {
    res.render('profile', { user: req.session.user });
});

module.exports = router;
