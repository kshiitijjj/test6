const express = require('express');
const session = require('express-session');
const path = require('path');
const helmet = require('helmet');
const profileRouter = require('./routes/profile');

const app = express();

// Use Helmet for security headers
app.use(helmet());

// Set up session management
app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // set secure: true if using HTTPS
}));

// Middleware to parse form data
app.use(express.urlencoded({ extended: true }));

// Set EJS as templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Route to display the login page
app.get('/login', (req, res) => {
    res.render('login');
});

// Redirect the root URL to the login page
app.get('/', (req, res) => {
    res.redirect('/login');
});

// Use profile route
app.use('/profile', profileRouter);

// Simulated login route for testing
app.post('/login', (req, res) => {
    req.session.user = {
        name: 'Kshitij shrestha',
        email: 'kshrestha@gmail.com',
        address: '12 st andrews rd, Toronto, ON',
        pincode: '1234'
    };
    res.redirect('/profile');
});

app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).send('Error logging out');
        }
        res.redirect('/login');
    });
});

// Start the server
app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
